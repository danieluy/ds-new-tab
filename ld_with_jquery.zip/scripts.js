$(document).ready(function () {
  getAccentColor();
  loadHoursRestrStatus();
  $(".color_option").click(setAccentColor);
  $("#chk_restr_hour").click(manageHoursRestrStatus);
  $("#reset_button").click(resetStoredData);
});


//GLOBAL VARIABLES/////////////////////////////////////////////////////////////////////////
var accent_color = "#4285f4";
var current_time = new Date();




//FUNCTIONS////////////////////////////////////////////////////////////////////////////////
function applyAccentColor() {
  $('.search_button,.link_card_header').css('background-color', accent_color);
}

function setAccentColor() {
  localStorage.setItem('accent_color', $(this).attr('color'));
  getAccentColor();
  //console.log('setAccentColor saved accent_color ' + $(this).attr('color'));
}


function getAccentColor() {
  if (localStorage) {
    var color = localStorage.getItem('accent_color');
    if (color !== null) {
      accent_color = color;
      applyAccentColor();
      //console.log('getAccentColor setted accent_color as ' + color);
    }
    else {
      accent_color = "#4285f4";
      //console.log('accent_color was set to default');
    }
  }
  else {
    alert('Este navegador no soporta el almacenamiento de datos locales');
  }
}


function loadHoursRestrStatus() {
  var stored_restrictions = localStorage.getItem('restrictions');
  if (stored_restrictions === 'true' || stored_restrictions === null) {
    stored_restrictions = true;
  }
  if (stored_restrictions === 'false') {
    stored_restrictions = false;
    $("#chk_restr_hour").removeAttr('checked');
  }
  filterLinks(stored_restrictions);
}

function manageHoursRestrStatus() {
  var restrictions = $("#chk_restr_hour").is(':checked');
  localStorage.setItem('restrictions', restrictions);
  filterLinks(restrictions);
}



function filterLinks(restrictions) {
  console.log("filterLinks(" + typeof restrictions + ' ' + restrictions + ") executed");
  var day_int = current_time.getDay();
  var hour_int = current_time.getHours();
  console.log('dia ' + day_int + ' hora ' + hour_int);
  //Time restrictions switch
  if (restrictions) {
    //Labor days
    if ((day_int >= 1) && (day_int <= 5)) {
      //Labor hours
      if ((hour_int >= 9) && (hour_int < 18)) {
        $(".link_wrapper").removeClass('hidden');
        $("#study_stuff, #fun_stuff").addClass('hidden');
        console.log('work hours restrictions applied');
      }
      //After hours
      else {
        $(".link_wrapper").removeClass('hidden');
        $("#work_stuff").addClass('hidden');
        console.log('after hours restrictions applied');
      }
    }
    //Weekend
    else {
      $(".link_wrapper").removeClass('hidden');
      $("#work_stuff").addClass('hidden');
      console.log('weekend restrictions applied');
    }
  }
  else {
    $(".link_wrapper").removeClass('hidden');
    console.log('no hour restrictions applied');
  }
}


function resetStoredData() {
  localStorage.clear();
  location.reload();
}


var link_card_headers = document.getElementsByClassName('link_card_header');

for (var x = 0; x < link_card_headers.length; x++) {
  link_card_headers[x].addEventListener('contextmenu', showContextMenu, false);
}

var context_menu_background = document.getElementById('context_menu_background');
context_menu_background.addEventListener('click', hideContextMenu, false);
context_menu_background.addEventListener('contextmenu', hideContextMenu, false);

function showContextMenu(evt) {
  evt.preventDefault();
  // To call this function use oncontextmenu="showContextMenu(event);return false" as an attribute on the trigger tag on the HTML document
  // Mouse position
  var x = evt.clientX;
  var y = evt.clientY;
	// The clientX clientY property returns the coordinate (according to the client area) of the mouse pointer when a mouse event was triggered.
	// The client area is the current window.
  var screen_width = $(window).width();
  if (screen_width - x < 200) x -= 200;
  $("#context_menu").attr('style', 'display:inherit; top:' + y + 'px; left:' + x + 'px');
  $("#context_menu_background").attr('style', 'display:inherit');
}


function hideContextMenu(evt) {
  evt.preventDefault();
  $("#context_menu, #context_menu_background").attr('style', 'display:none');
}

